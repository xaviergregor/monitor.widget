#!/usr/bin/env python3
# stats.py — Xavier / gregor.fr

import subprocess, json, re, os, time
from datetime import datetime

now = datetime.now()

# ── CPU total + nb cœurs ─────────────────────────────────────────────────────
try:
    raw  = subprocess.check_output(
        ['bash', '-c', "ps -A -o pcpu | tail -n +2 | awk '{s+=$1} END {printf \"%.1f\", s}'"],
        text=True, timeout=4
    ).strip()
    ncpu = int(subprocess.check_output(['sysctl', '-n', 'hw.logicalcpu'], text=True).strip())
    cpu  = round(float(raw) / ncpu, 1)
except:
    cpu  = 0.0
    ncpu = 1

# ── CPU par cœur (top -R, deux passes) ───────────────────────────────────────
try:
    top_r = subprocess.check_output(
        ['top', '-l', '2', '-n', '0', '-R'], text=True, timeout=6
    )
    cores = []
    for line in top_r.split('\n'):
        m = re.search(r'CPU\d+\s+usage:\s+([\d.]+)%\s+user.*?([\d.]+)%\s+sys', line)
        if not m:
            m = re.search(r'Processor \d+.*?:\s+([\d.]+)%\s+user.*?([\d.]+)%\s+sys', line)
        if m:
            cores.append(round(float(m.group(1)) + float(m.group(2)), 1))
    if not cores:
        cores = [cpu] * ncpu
except:
    cores = [cpu] * ncpu

# ── Température CPU ───────────────────────────────────────────────────────────
temp = None
for path in ['/opt/homebrew/bin/osx-cpu-temp', '/usr/local/bin/osx-cpu-temp']:
    try:
        t_out = subprocess.check_output([path], text=True).strip()
        m = re.search(r'([\d.]+)', t_out)
        if m:
            temp = round(float(m.group(1)), 1)
            break
    except:
        pass

# ── Ping 1.1.1.1 ─────────────────────────────────────────────────────────────
try:
    ping_out = subprocess.check_output(
        ['ping', '-c', '1', '-W', '1000', '1.1.1.1'],
        text=True, timeout=3
    )
    m = re.search(r'time=([\d.]+)', ping_out)
    ping_ms = round(float(m.group(1)), 1) if m else None
except:
    ping_ms = None

# ── RAM ───────────────────────────────────────────────────────────────────────
try:
    vm   = subprocess.check_output(['vm_stat'], text=True)
    pgsz = 4096
    def vp(lbl):
        m = re.search(lbl + r'\s+(\d+)', vm)
        return int(m.group(1)) if m else 0
    pf = vp('Pages free:')
    pi = vp('Pages inactive:')
    ps = vp('Pages speculative:')
    pu = vp('Pages purgeable:')
    pw = vp('Pages wired down:')
    pa = vp('Pages active:')
    pc = vp('Pages occupied by compressor:')
    ms  = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True).strip())
    tot   = ms / 1024**3
    avail = (pf + pi + ps + pu) * pgsz / 1024**3
    usd   = tot - avail
    ram = {
        'used':       round(usd, 1),
        'total':      round(tot, 1),
        'avail':      round(avail, 1),
        'free':       round(pf * pgsz / 1024**3, 1),
        'cached':     round(pi * pgsz / 1024**3, 1),
        'wired':      round(pw * pgsz / 1024**3, 1),
        'active':     round(pa * pgsz / 1024**3, 1),
        'compressed': round(pc * pgsz / 1024**3, 1),
        'pct':        min(100, round(usd / tot * 100))
    }
except:
    ram = {'used':0,'total':0,'avail':0,'free':0,'cached':0,'wired':0,'active':0,'compressed':0,'pct':0}

# ── Memory pressure ───────────────────────────────────────────────────────────
try:
    mp = int(subprocess.check_output(['sysctl', '-n', 'vm.memory_pressure'], text=True).strip())
    mem_pressure = 'NORMAL' if mp == 1 else 'WARN' if mp == 2 else 'CRITICAL' if mp == 4 else 'NORMAL'
except:
    mem_pressure = 'NORMAL'

# ── Uptime ────────────────────────────────────────────────────────────────────
try:
    ut   = subprocess.check_output(['uptime'], text=True).strip()
    up_m = re.search(r'up\s+(.+?),\s+\d+\s+user', ut)
    uptime = up_m.group(1).strip() if up_m else 'unknown'
except:
    uptime = 'unknown'

# ── Battery ───────────────────────────────────────────────────────────────────
try:
    bo       = subprocess.check_output(['pmset', '-g', 'batt'], text=True)
    bp       = int(re.search(r'(\d+)%', bo).group(1))
    charging = 'charging' in bo.lower() and 'discharging' not in bo.lower()
    batt     = {'pct': bp, 'charging': charging}
except:
    batt = None

# ── Disk ──────────────────────────────────────────────────────────────────────
try:
    df_sys  = subprocess.check_output(['df','-H','/'], text=True).split('\n')[1].split()
    df_data = subprocess.check_output(['df','-H','/System/Volumes/Data'], text=True).split('\n')[1].split()
    def parse_size(s):
        s = s.strip()
        if s.endswith('T'): return float(s[:-1]) * 1024
        if s.endswith('G'): return float(s[:-1])
        if s.endswith('M'): return float(s[:-1]) / 1024
        return 0.0
    def fmt_gb(v):
        return f"{v:.0f} Go" if v >= 10 else f"{v:.1f} Go"
    used_gb  = parse_size(df_sys[2]) + parse_size(df_data[2])
    total_gb = parse_size(df_sys[1])
    pct      = round(used_gb / total_gb * 100) if total_gb > 0 else 0
    disk = {'used': fmt_gb(used_gb), 'total': fmt_gb(total_gb), 'pct': min(100, pct)}
except:
    disk = {'used':'?','total':'?','pct':0}

# ── Processus top 10 ─────────────────────────────────────────────────────────
try:
    ps_c = int(subprocess.check_output(['bash','-c','ps aux | wc -l'], text=True).strip()) - 1
    psl  = subprocess.check_output(['ps','aux','-r'], text=True).strip().split('\n')[1:15]
    procs = []
    for l in psl:
        p = l.split(None, 10)
        if len(p) >= 11:
            nm = p[10].split('/')[-1][:20]
            if nm == 'stats.py': continue
            procs.append({'pid':p[1],'cpu':p[2],'mem':p[3],'name':nm})
            if len(procs) == 10: break
except:
    ps_c = 0
    procs = []

# ── Réseau temps réel (double échantillon 1s) ────────────────────────────────
def fmt_speed(bps):
    if bps >= 1024**2: return f"{bps/1024**2:.1f} MB/s"
    if bps >= 1024:    return f"{bps/1024:.0f} KB/s"
    return f"{int(bps)} B/s"

def net_bytes(iface):
    out    = subprocess.check_output(["netstat", "-I", iface, "-b"], text=True)
    lines  = out.strip().split("\n")
    header = lines[0].split()
    try:
        ic = header.index("Ibytes")
        oc = header.index("Obytes")
    except ValueError:
        ic, oc = 6, 9
    rx = tx = 0
    for l in lines[1:]:
        p = l.split()
        if len(p) > max(ic, oc):
            try:
                rx = max(rx, int(p[ic]))
                tx = max(tx, int(p[oc]))
            except:
                pass
    return rx, tx

try:
    route_out = subprocess.check_output(["route", "-n", "get", "default"], text=True)
    m_iface   = re.search(r"interface:\s+(\S+)", route_out)
    iface     = m_iface.group(1) if m_iface else "en0"
    rx1, tx1  = net_bytes(iface)
    time.sleep(1)
    rx2, tx2  = net_bytes(iface)
    rx_s = max(0, rx2 - rx1)
    tx_s = max(0, tx2 - tx1)
    net = {"iface": iface, "rx": fmt_speed(rx_s), "tx": fmt_speed(tx_s),
           "rx_bps": round(rx_s), "tx_bps": round(tx_s)}
except:
    net = {"iface":"?","rx":"---","tx":"---","rx_bps":0,"tx_bps":0}

# ── Hostname + IP ─────────────────────────────────────────────────────────────
try:
    hostname = subprocess.check_output(['hostname','-s'], text=True).strip()
except:
    hostname = 'mac'
try:
    ip = subprocess.check_output(
        ['bash','-c','ipconfig getifaddr en0 2>/dev/null || echo —'], text=True).strip()
except:
    ip = '—'

# ── Sortie JSON ───────────────────────────────────────────────────────────────
print(json.dumps({
    'date':         now.strftime('%d/%m/%Y'),
    'time':         now.strftime('%H:%M:%S'),
    'hostname':     hostname,
    'ip':           ip,
    'cpu':          cpu,
    'cores':        cores,
    'temp':         temp,
    'ping_ms':      ping_ms,
    'ram':          ram,
    'mem_pressure': mem_pressure,
    'uptime':       uptime,
    'batt':         batt,
    'disk':         disk,
    'ps_count':     ps_c,
    'procs':        procs,
    'net':          net,
}))
