// Monitor — Übersicht widget v5
// Xavier Gregor / gregor.fr — temp + ping + core grid

export const command = 'python3 "$HOME/Library/Application Support/Übersicht/widgets/monitor.widget/stats.py"'
export const refreshFrequency = 3000

// ── historique sparklines ─────────────────────────────────────────────────────
var MAX_H = 40
var cpuH  = [], ramH  = [], rxH   = [], txH   = []
var tempH = [], pingH = []

function pushH(arr, val) {
  arr.push(val)
  if (arr.length > MAX_H) arr.shift()
}

// ── construction path SVG bezier ─────────────────────────────────────────────
function makePath(data, W, H, maxOverride) {
  var n      = MAX_H
  var padded = []
  for (var i = 0; i < Math.max(0, n - data.length); i++) padded.push(0)
  padded = padded.concat(data.slice(-n))
  var max = maxOverride || 1
  if (!maxOverride) { for (var i = 0; i < padded.length; i++) { if (padded[i] > max) max = padded[i] } }
  var pts = padded.map(function(v, i) {
    return { x: (i/(n-1))*W, y: H - (v/max)*(H-6) - 3 }
  })
  var line = 'M'+pts[0].x.toFixed(1)+','+pts[0].y.toFixed(1)
  for (var i = 1; i < pts.length; i++) {
    var p = pts[i-1], q = pts[i], cx = ((p.x+q.x)/2).toFixed(1)
    line += ' C'+cx+','+p.y.toFixed(1)+' '+cx+','+q.y.toFixed(1)+' '+q.x.toFixed(1)+','+q.y.toFixed(1)
  }
  var last = pts[pts.length-1]
  return { line: line, fill: line+' L'+last.x.toFixed(1)+','+H+' L0,'+H+' Z', last: last }
}

// ── Spark simple ──────────────────────────────────────────────────────────────
function Spark(props) {
  var W = 258, H = props.h || 38
  var data = props.data, color = props.color, gradId = props.gradId
  var warnAt = props.warnAt || 70, dangerAt = props.dangerAt || 90
  var val    = data.length > 0 ? data[data.length-1] : 0
  var stroke = val >= dangerAt ? '#f85149' : val >= warnAt ? '#e3b341' : color
  var p      = makePath(data, W, H, props.maxVal || null)
  return (
    <svg width={W} height={H} style={{display:'block',overflow:'visible',margin:'2px 0 6px'}}>
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor={stroke} stopOpacity="0.28"/>
          <stop offset="100%" stopColor={stroke} stopOpacity="0.02"/>
        </linearGradient>
      </defs>
      <path d={p.fill} fill={'url(#'+gradId+')'}/>
      <path d={p.line} fill="none" stroke={stroke} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={p.last.x} cy={p.last.y} r="2.5" fill={stroke}/>
      <circle cx={p.last.x} cy={p.last.y} r="5"   fill={stroke} fillOpacity="0.18"/>
    </svg>
  )
}

// ── SparkDuo : deux courbes superposées, échelle commune ─────────────────────
function SparkDuo(props) {
  var W = 258, H = 46
  var dataA = props.dataA, colorA = props.colorA, gradA = props.gradA
  var dataB = props.dataB, colorB = props.colorB, gradB = props.gradB
  var all = dataA.concat(dataB), gMax = 1
  for (var i = 0; i < all.length; i++) { if (all[i] > gMax) gMax = all[i] }
  var pA = makePath(dataA, W, H, gMax)
  var pB = makePath(dataB, W, H, gMax)
  return (
    <svg width={W} height={H} style={{display:'block',overflow:'visible',margin:'3px 0 7px'}}>
      <defs>
        <linearGradient id={gradA} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colorA} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={colorA} stopOpacity="0.02"/>
        </linearGradient>
        <linearGradient id={gradB} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colorB} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={colorB} stopOpacity="0.02"/>
        </linearGradient>
      </defs>
      <path d={pA.fill} fill={'url(#'+gradA+')'}/>
      <path d={pB.fill} fill={'url(#'+gradB+')'}/>
      <path d={pA.line} fill="none" stroke={colorA} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d={pB.line} fill="none" stroke={colorB} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pA.last.x} cy={pA.last.y} r="2.5" fill={colorA}/>
      <circle cx={pB.last.x} cy={pB.last.y} r="2.5" fill={colorB}/>
    </svg>
  )
}

// ── Grille des cœurs CPU ──────────────────────────────────────────────────────
function CoreGrid(props) {
  var cores = props.cores
  if (!cores || cores.length === 0) return null
  var n    = cores.length
  var cols = n <= 8 ? Math.ceil(n / 2) : Math.ceil(n / 3)
  var W    = 258
  var size = Math.floor((W - (cols - 1) * 4) / cols)

  function coreColor(pct) {
    if (pct >= 80) return '#f85149'
    if (pct >= 50) return '#e3b341'
    if (pct >= 20) return '#3fb950'
    return 'rgba(63,185,80,0.25)'
  }

  return (
    <div style={{display:'flex',flexWrap:'wrap',gap:'4px',margin:'4px 0 8px'}}>
      {cores.map(function(pct, i) {
        var col = coreColor(pct)
        return (
          <div key={i} style={{
            width: size+'px', height: size+'px',
            background: 'rgba(63,185,80,0.06)',
            border: '1px solid rgba(63,185,80,0.15)',
            borderRadius: '3px',
            position: 'relative',
            overflow: 'hidden'
          }}>
            <div style={{
              position:'absolute', bottom:0, left:0, right:0,
              height: pct+'%',
              background: col,
              opacity: 0.75,
              transition: 'height 0.4s ease'
            }}/>
            <span style={{
              position:'absolute', bottom:'1px', left:0, right:0,
              textAlign:'center', fontSize:'7px', color:'rgba(255,255,255,0.7)',
              lineHeight:'1'
            }}>{Math.round(pct)}</span>
          </div>
        )
      })}
    </div>
  )
}

// ── Barre horizontale ─────────────────────────────────────────────────────────
function Bar(props) {
  var pct = props.pct
  var color = pct >= (props.dangerAt||90) ? '#f85149' : pct >= (props.warnAt||75) ? '#e3b341' : '#3fb950'
  return (
    <div style={{height:'3px',background:'rgba(63,185,80,0.09)',borderRadius:'2px',overflow:'hidden',margin:'3px 0 7px'}}>
      <div style={{height:'100%',width:Math.min(100,pct)+'%',background:color,borderRadius:'2px'}}/>
    </div>
  )
}

function SLabel(props) {
  return <span style={{fontSize:'9px',color:'rgba(63,185,80,0.35)',letterSpacing:'0.10em',textTransform:'uppercase'}}>{props.children}</span>
}
function Row(props) {
  return <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:(props.mb||1)+'px'}}>{props.children}</div>
}
function Sep() {
  return <div style={{borderTop:'1px solid rgba(63,185,80,0.12)',margin:'8px 0'}}/>
}


// ── Globe animé ───────────────────────────────────────────────────────────────
function Globe() {
  var R = 27, cx = 28, cy = 28, S = 56

  var css = [
    '@keyframes gmspin {',
    '  0%   { transform: scaleX(1);    }',
    '  50%  { transform: scaleX(0.01); }',
    '  100% { transform: scaleX(-1);   }',
    '}',
    '.gm {',
    '  transform-box: fill-box;',
    '  transform-origin: center;',
    '  animation: gmspin 5s linear infinite;',
    '}',
    '.gm2 { animation-delay: -1.25s; }',
    '.gm3 { animation-delay: -2.5s;  }',
    '.gm4 { animation-delay: -3.75s; }'
  ].join('\n')

  return (
    <svg width={S} height={S} viewBox={'0 0 '+S+' '+S}
         style={{display:'block', filter:'drop-shadow(0 0 5px rgba(63,185,80,0.35))'}}>
      <defs>
        <clipPath id="gclip"><circle cx={cx} cy={cy} r={R}/></clipPath>
        <style>{css}</style>
      </defs>

      <circle cx={cx} cy={cy} r={R} fill="rgba(13,17,23,0.75)"/>

      <g clipPath="url(#gclip)">
        {/* latitudes */}
        <ellipse cx={cx} cy={cy-14} rx={21} ry={5} fill="none" stroke="#3fb950" strokeWidth="0.55" opacity="0.35"/>
        <ellipse cx={cx} cy={cy}    rx={R}  ry={7} fill="none" stroke="#3fb950" strokeWidth="0.70" opacity="0.50"/>
        <ellipse cx={cx} cy={cy+14} rx={21} ry={5} fill="none" stroke="#3fb950" strokeWidth="0.55" opacity="0.35"/>
        {/* méridiens animés */}
        <ellipse className="gm"     cx={cx} cy={cy} rx={R} ry={R} fill="none" stroke="#3fb950" strokeWidth="0.65" opacity="0.55"/>
        <ellipse className="gm gm2" cx={cx} cy={cy} rx={R} ry={R} fill="none" stroke="#3fb950" strokeWidth="0.65" opacity="0.55"/>
        <ellipse className="gm gm3" cx={cx} cy={cy} rx={R} ry={R} fill="none" stroke="#3fb950" strokeWidth="0.65" opacity="0.55"/>
        <ellipse className="gm gm4" cx={cx} cy={cy} rx={R} ry={R} fill="none" stroke="#3fb950" strokeWidth="0.65" opacity="0.55"/>
      </g>

      <circle cx={cx} cy={cy} r={R} fill="none" stroke="#3fb950" strokeWidth="1"/>
    </svg>
  )
}

export const className = `
  position: fixed;
  top: 20px;
  right: 20px;
  font-family: 'JetBrains Mono', 'Menlo', monospace;
  font-size: 11px;
  line-height: 1.6;
  color: #3fb950;
  background: transparent;
  width: 290px;
  z-index: 1000;
  text-shadow: 0 0 8px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.8);
`

var DIM    = 'rgba(63,185,80,0.35)'
var MID    = 'rgba(63,185,80,0.65)'
var GREEN  = '#3fb950'
var BLUE   = '#58a6ff'
var YELLOW = '#e3b341'
var RED    = '#f85149'
var ORANGE = '#F77E2D'

export const render = function(props) {
  var output = props.output
  if (!output) return <div/>
  var d
  try { d = JSON.parse(output) }
  catch(e) { return <div style={{color:RED,fontSize:'10px'}}>err: {(output||'').slice(0,60)}</div> }

  pushH(cpuH,  d.cpu)
  pushH(ramH,  d.ram.pct)
  pushH(rxH,   d.net.rx_bps / 1024)
  pushH(txH,   d.net.tx_bps / 1024)
  if (d.temp    != null) pushH(tempH, d.temp)
  if (d.ping_ms != null) pushH(pingH, d.ping_ms)

  var cpuColor  = d.cpu >= 90 ? RED : d.cpu >= 70 ? YELLOW : BLUE
  var pingColor = !d.ping_ms ? MID : d.ping_ms >= 100 ? RED : d.ping_ms >= 50 ? YELLOW : GREEN

  return (
    <div>

      {/* ── Header ── */}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'10px'}}>
        <div>
          <div style={{color:GREEN,fontSize:'13px',fontWeight:'bold',letterSpacing:'0.05em',marginBottom:'3px'}}>{d.hostname}</div>
          <div style={{color:DIM,fontSize:'12px',marginBottom:'3px'}}>{d.time}</div>
          <div style={{color:DIM,fontSize:'9.5px'}}>{d.date} · {d.ip}</div>
          <div style={{color:DIM,fontSize:'9.5px'}}>up {d.uptime}</div>
        </div>
        <Globe/>
      </div>

      {/* ── CPU + Température ── */}
      <Row mb={0}>
        <SLabel>CPU</SLabel>
        <span>
          <span style={{color:cpuColor,fontSize:'11px'}}>{d.cpu}%</span>
        </span>
      </Row>
      <Spark data={cpuH} color={GREEN} gradId="g-cpu" warnAt={70} dangerAt={90}/>


      <Sep/>

      {/* ── RAM ── */}
      <Row mb={0}>
        <SLabel>RAM</SLabel>
        <span style={{fontSize:'10px'}}>
          <span style={{color:BLUE}}>{d.ram.used} GiB</span>
          <span style={{color:DIM}}> / {d.ram.total} GiB · </span>
          <span style={{color:MID}}>{d.ram.pct}%</span>
        </span>
      </Row>
      <Spark data={ramH} color={BLUE} gradId="g-ram" warnAt={75} dangerAt={90}/>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',fontSize:'9.5px',marginTop:'-3px',marginBottom:'3px',rowGap:'2px'}}>
        <span><span style={{color:DIM}}>free   </span><span style={{color:MID}}>{d.ram.free} G</span></span>
        <span><span style={{color:DIM}}>avail  </span><span style={{color:MID}}>{d.ram.avail} G</span></span>
        <span><span style={{color:DIM}}>cached </span><span style={{color:MID}}>{d.ram.cached} G</span></span>
        <span><span style={{color:DIM}}>wired  </span><span style={{color:MID}}>{d.ram.wired} G</span></span>
        <span><span style={{color:DIM}}>active </span><span style={{color:MID}}>{d.ram.active} G</span></span>
        <span><span style={{color:DIM}}>compr  </span><span style={{color:MID}}>{d.ram.compressed} G</span></span>
      </div>
      <div style={{fontSize:'9px',marginBottom:'8px'}}>
        <span style={{color:DIM}}>pressure </span>
        <span style={{color:d.mem_pressure==='CRITICAL'?RED:d.mem_pressure==='WARN'?YELLOW:GREEN}}>{d.mem_pressure}</span>
      </div>

      {/* ── Battery ── */}
      {d.batt && (
        <div style={{display:'flex',justifyContent:'flex-end',marginBottom:'6px'}}>
          <span style={{fontSize:'10px'}}>
            <span style={{color:DIM}}>bat </span>
            <span style={{color:d.batt.pct<=10?RED:d.batt.pct<=25?YELLOW:GREEN}}>{d.batt.pct}%</span>
            {d.batt.charging && <span style={{color:DIM}}> ⚡</span>}
          </span>
        </div>
      )}

      <Sep/>

      {/* ── Réseau + Ping ── */}
      <Row mb={0}>
        <SLabel>Network {d.net.iface}</SLabel>
        {d.ping_ms != null && (
          <span style={{fontSize:'9px'}}>
            <span style={{color:DIM}}>ping </span>
            <span style={{color:pingColor}}>{d.ping_ms} ms</span>
          </span>
        )}
      </Row>
      <div style={{display:'flex',justifyContent:'space-between',margin:'3px 0 3px'}}>
        <span style={{fontSize:'10px'}}><span style={{color:DIM}}>↑ </span><span style={{color:ORANGE}}>{d.net.tx}</span></span>
        <span style={{fontSize:'10px'}}><span style={{color:DIM}}>↓ </span><span style={{color:BLUE}}>{d.net.rx}</span></span>
      </div>
      <SparkDuo dataA={txH} colorA={ORANGE} gradA="g-tx" dataB={rxH} colorB={BLUE} gradB="g-rx"/>


      <Sep/>

      {/* ── Disk ── */}
      <Row mb={0}>
        <SLabel>Disk /</SLabel>
        <span style={{fontSize:'10px'}}>
          <span style={{color:MID}}>{d.disk.used} / {d.disk.total}</span>
          <span style={{color:d.disk.pct>85?YELLOW:DIM,marginLeft:'6px'}}>{d.disk.pct}%</span>
        </span>
      </Row>
      <Bar pct={d.disk.pct} warnAt={75} dangerAt={90}/>

      {/* ── Top 10 Processes ── */}
      <Row mb={5}>
        <SLabel>Top Processes</SLabel>
        <span style={{color:DIM,fontSize:'9px'}}>{d.ps_count} running</span>
      </Row>
      <div style={{display:'grid',gridTemplateColumns:'1fr 42px 38px 38px',color:DIM,fontSize:'9px',textTransform:'uppercase',letterSpacing:'0.05em',marginBottom:'3px'}}>
        <span>Name</span><span>PID</span><span>CPU</span><span>MEM</span>
      </div>
      {d.procs.map(function(p, i) {
        var cpuVal = parseFloat(p.cpu) || 0
        var col    = cpuVal >= 20 ? RED : cpuVal >= 8 ? YELLOW : i===0 ? GREEN : MID
        return (
          <div key={p.pid} style={{display:'grid',gridTemplateColumns:'1fr 42px 38px 38px',fontSize:'10px',marginBottom:'2px'}}>
            <span style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',paddingRight:'4px',color:col}}>{p.name}</span>
            <span style={{color:DIM}}>{p.pid}</span>
            <span style={{color:col}}>{p.cpu}</span>
            <span style={{color:MID}}>{p.mem}</span>
          </div>
        )
      })}

    </div>
  )
}
